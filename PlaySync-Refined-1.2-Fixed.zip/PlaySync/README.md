# PlaySync Refined 1.1

This is a cleaned version of the original PlaySync project. Game-specific logic is no longer stored in `host.html`; each game is a module registered in `public/games/registry.js`.

## Run

```bash
npm install
npm start
```

Open `http://localhost:3000/` on the host PC. Phones on the same Wi-Fi can scan the QR code.

## Structure

```text
public/
  index.html
  host.html
  controller.html
  games/
    registry.js
    slip-n-bump.js
    cyber-tank.js
  js/
    home.js
    host-app.js
  css/
    home.css
    host.css
    controller.css
server/
  server.js
  rooms.js
```

### Why this is better
- `host.html` contains UI only; game rules live in game modules.
- `registry.js` is the single place to register future games.
- Room/slot management is centralized in `server/rooms.js`.
- QR generation happens server-side, removing a second browser QR dependency.
- The live leaderboard is fed by host-authoritative scores and persisted in room state.
- Player slots are reused after disconnects.
- Controller input is cleared on blur/visibility changes so movement cannot get stuck.
- The old constantly-running particle network and empty/duplicate animation scripts are removed from the active path.
- Slip N Bump now has rounds, a timer, power-ups, knockouts and match scoring.
- Cyber Tank has rounds, HP, ricochet shots, cover, boost and scoring.
