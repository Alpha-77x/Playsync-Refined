const COLORS = ['#ff4757','#2ed573','#1e90ff','#ffa502','#9b59b6','#00d2d3','#ff6b81','#a4b0be'];

export function createGame({ container, players, onScores, onStatus }) {
  const canvas = document.createElement('canvas');
  canvas.className = 'game-canvas';
  container.appendChild(canvas);
  const ctx = canvas.getContext('2d', { alpha: false });
  const state = {
    players: new Map(), running: false, frame: 0, last: 0,
    round: 1, phase: 'countdown', timer: 3, hud: null,
    W: 0, H: 0, powerups: []
  };

  const scores = () => [...state.players.values()].map(p => ({ id: p.id, score: p.score }));
  const message = (text) => { const e = state.hud?.querySelector('#m'); if (e) e.textContent = text; };
  const phase = (value) => { state.phase = value; const e = state.hud?.querySelector('#p'); if (e) e.textContent = value === 'playing' ? 'LIVE' : value.toUpperCase(); };

  function makeHud() {
    const h = document.createElement('div');
    h.className = 'game-hud';
    h.innerHTML = '<div class="game-hud-top"><span class="game-pill" id="r">ROUND 1/3</span><span class="game-pill" id="p">GET READY</span></div><div class="game-hud-message" id="m">GET READY</div>';
    container.appendChild(h);
    state.hud = h;
  }

  function resize() {
    state.W = container.clientWidth || innerWidth;
    state.H = container.clientHeight || innerHeight;
    const dpr = Math.min(devicePixelRatio || 1, 1.5);
    canvas.width = Math.max(1, Math.floor(state.W * dpr));
    canvas.height = Math.max(1, Math.floor(state.H * dpr));
    canvas.style.width = `${state.W}px`;
    canvas.style.height = `${state.H}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function spawnPos(slot) {
    const pos = [[.12,.15],[.88,.15],[.12,.85],[.88,.85],[.35,.15],[.65,.15],[.35,.85],[.65,.85]][(slot - 1) % 8];
    return { x: pos[0] * state.W, y: pos[1] * state.H };
  }

  function add(id, data) {
    const pos = spawnPos(data.slot || 1);
    state.players.set(id, {
      ...data,
      color: data.color || COLORS[(data.slot - 1) % COLORS.length],
      x: pos.x, y: pos.y, vx: 0, vy: 0,
      score: data.score || 0, alive: true,
      dash: 0, shield: 0,
      input: { u:false, d:false, l:false, r:false }
    });
  }

  function remove(id) { state.players.delete(id); }

  function resetRound() {
    state.players.forEach(p => {
      const pos = spawnPos(p.slot);
      p.x = pos.x; p.y = pos.y; p.vx = 0; p.vy = 0;
      p.alive = true; p.dash = 0; p.shield = 0;
      p.input = { u:false, d:false, l:false, r:false };
    });
    state.powerups = [];
    state.timer = 3;
    phase('countdown');
    message('GET READY');
    const r = state.hud?.querySelector('#r');
    if (r) r.textContent = `ROUND ${state.round}/3`;
  }

  function eliminate(p) {
    if (!p.alive) return;
    p.alive = false;
    p.score += 25;
    onScores(scores());
    const alive = [...state.players.values()].filter(x => x.alive);
    if (alive.length <= 1) {
      if (alive[0]) {
        alive[0].score += 100;
        message(`${alive[0].name} WINS ROUND ${state.round}`);
      } else message('NO SURVIVOR');
      onScores(scores());
      state.timer = 3.2;
      phase('round-over');
    }
  }

  function action(id, a) {
    const p = state.players.get(id);
    if (!p || !p.alive || state.phase !== 'playing') return;
    const map = {
      MOVE_UP_START:['u',true], MOVE_UP_STOP:['u',false],
      MOVE_DOWN_START:['d',true], MOVE_DOWN_STOP:['d',false],
      MOVE_LEFT_START:['l',true], MOVE_LEFT_STOP:['l',false],
      MOVE_RIGHT_START:['r',true], MOVE_RIGHT_STOP:['r',false]
    };
    if (map[a]) p.input[map[a][0]] = map[a][1];
    if ((a === 'ACTION_A_START' || a === 'ACTION_B_START') && p.dash <= 0) {
      const dx = (p.input.r ? 1 : 0) - (p.input.l ? 1 : 0);
      const dy = (p.input.d ? 1 : 0) - (p.input.u ? 1 : 0);
      const n = Math.hypot(dx, dy) || 1;
      p.vx += dx / n * 360;
      p.vy += dy / n * 360;
      p.dash = .55;
      if (a === 'ACTION_B_START') p.shield = 1.3;
    }
  }

  function update(dt) {
    if (state.phase === 'countdown') {
      state.timer -= dt;
      message(state.timer > 0 ? String(Math.ceil(state.timer)) : 'GO!');
      if (state.timer <= 0) phase('playing');
      return;
    }
    if (state.phase === 'round-over') {
      state.timer -= dt;
      if (state.timer <= 0) {
        if (state.round >= 3) {
          const winner = [...state.players.values()].sort((a,b)=>b.score-a.score)[0];
          message(winner ? `${winner.name} WINS THE MATCH` : 'MATCH COMPLETE');
          phase('finished'); onStatus('finished');
        } else {
          state.round += 1;
          resetRound();
        }
      }
      return;
    }
    if (state.phase !== 'playing') return;

    state.timer -= dt;
    if (state.timer <= 0) {
      message('TIME UP');
      state.timer = 3.2;
      phase('round-over');
      return;
    }

    for (const p of state.players.values()) {
      if (!p.alive) continue;
      const accel = p.dash > 0 ? 1400 : 900;
      if (p.input.u) p.vy -= accel * dt;
      if (p.input.d) p.vy += accel * dt;
      if (p.input.l) p.vx -= accel * dt;
      if (p.input.r) p.vx += accel * dt;

      p.vx *= Math.pow(.035, dt);
      p.vy *= Math.pow(.035, dt);
      const speed = Math.hypot(p.vx,p.vy);
      const max = p.dash > 0 ? 550 : 300;
      if (speed > max) { p.vx = p.vx / speed * max; p.vy = p.vy / speed * max; }

      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.dash = Math.max(0, p.dash - dt);
      p.shield = Math.max(0, p.shield - dt);

      if (p.x < 34 || p.x > state.W - 34 || p.y < 90 || p.y > state.H - 34) eliminate(p);
    }

    const list = [...state.players.values()];
    for (let i=0;i<list.length;i++) for (let j=i+1;j<list.length;j++) {
      const a = list[i], b = list[j];
      if (!a.alive || !b.alive) continue;
      const dx=b.x-a.x, dy=b.y-a.y, d=Math.hypot(dx,dy)||.001, min=54;
      if (d < min) {
        const nx=dx/d, ny=dy/d, push=(min-d)*.5;
        a.x-=nx*push; a.y-=ny*push; b.x+=nx*push; b.y+=ny*push;
        const force = 180;
        if (a.shield<=0) { a.vx-=nx*force; a.vy-=ny*force; }
        if (b.shield<=0) { b.vx+=nx*force; b.vy+=ny*force; }
      }
    }
  }

  function render() {
    const w = state.W, h = state.H;
    ctx.fillStyle = '#07111f'; ctx.fillRect(0,0,w,h);
    const g = ctx.createRadialGradient(w*.5,h*.4,40,w*.5,h*.45,Math.max(w,h)*.75);
    g.addColorStop(0,'rgba(0,242,255,.12)'); g.addColorStop(1,'rgba(3,6,12,0)');
    ctx.fillStyle = g; ctx.fillRect(0,0,w,h);

    ctx.strokeStyle='rgba(0,242,255,.05)'; ctx.lineWidth=1;
    for(let x=0;x<w;x+=56){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke()}
    for(let y=0;y<h;y+=56){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke()}

    ctx.fillStyle='#13263a'; ctx.fillRect(14,80,w-28,h-94);
    ctx.strokeStyle='rgba(0,242,255,.45)'; ctx.lineWidth=3; ctx.strokeRect(14,80,w-28,h-94);

    const active=[...state.players.values()];
    for(const p of active){
      if(!p.alive){ctx.fillStyle='rgba(255,71,87,.55)';ctx.font='700 12px Inter';ctx.textAlign='center';ctx.fillText('NEXT ROUND',p.x,p.y);continue}
      ctx.save(); ctx.translate(p.x,p.y);
      ctx.shadowBlur=18; ctx.shadowColor=p.color;
      ctx.fillStyle=p.color; ctx.beginPath(); ctx.arc(0,0,22,0,Math.PI*2); ctx.fill();
      ctx.shadowBlur=0;
      ctx.fillStyle='#0b1020'; ctx.beginPath(); ctx.arc(7,-3,8,0,Math.PI*2); ctx.fill();
      if(p.shield>0){ctx.strokeStyle='#6de7ff';ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,0,29,0,Math.PI*2);ctx.stroke()}
      ctx.restore();
      ctx.fillStyle='#fff'; ctx.font='700 13px Inter'; ctx.textAlign='center'; ctx.fillText(`${p.name} · ${p.score}`,p.x,p.y-34);
    }
  }

  function loop() {
    if (!state.running) return;
    const now = performance.now();
    const dt = Math.min((now - state.last) / 1000, .05);
    state.last = now;
    update(dt); render();
    state.frame = requestAnimationFrame(loop);
  }

  function start() {
    resize(); makeHud();
    state.round = 1; state.running = true; state.last = performance.now();
    resetRound(); onStatus('running'); loop();
  }

  function stop() {
    state.running = false;
    cancelAnimationFrame(state.frame);
    state.hud?.remove(); canvas.remove();
    state.players.clear(); state.powerups = [];
  }

  return { start, stop, resize, handleAction: action, addPlayer: (id,d) => state.running && add(id,d), removePlayer: remove, getScores: scores };
}
